#2018 Embedded Software Contest (Autonomous driving part), South Korea

##Gachon University
###TAKE OUT, Development Group, electric engineering, 

Juhyeong Kim.