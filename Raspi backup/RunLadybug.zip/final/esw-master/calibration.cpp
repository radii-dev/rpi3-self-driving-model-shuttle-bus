#include "system_management.h"
#include "calibration.h"
std::ofstream Calibration_result("calibration_result");
/*
bool Calibrator::wait_properEnviroment()
{
    return false;
}
void Calibrator::vertical()
{
	int i,j;
	if( (VPE_OUTPUT_W == 320) & (VPE_OUTPUT_H == 180) )
	{
		for(i = 0; i < 32; i++)
		{

		}
	}
	else Calibration_result << "VPE_OUTPUT is not 320 * 180";
	Calibration_result.close();
}
*/