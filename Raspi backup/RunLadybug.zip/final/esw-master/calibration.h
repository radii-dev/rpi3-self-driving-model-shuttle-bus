class Calibrator
{
	public:
		bool wait_properEnviroment();
		void vertical();
		void horizontale();
	private:
		
};