#2018 Embedded Software Contest (Autonomous driving part), South Korea

##Gachon University
###TAKE OUT, Development Group, electric engineering, 

Juhyeong Kim.


####inheritor

#2019 Gachon Capstone Design Competition, South Korea

##Gachon University
###TAKE OUT, Development Group, electric engineering, 

Seongwook Kang.